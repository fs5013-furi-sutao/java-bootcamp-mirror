public class Main {
    public static void main(String[] args) {
        Learning test = new Learning();
        
        test.start();
    }
}
